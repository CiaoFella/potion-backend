export class SignUpDto {
  email: string;
  password: string;
}

export class LoginDto {
  email: string;
  password: string;
}
